//header file for communication module
#define COMM

#define URL "http://www.cc.puv.fi/~e1601137/php/raspsound.php"
//specified page

//function prototype
void send_data(double[]);

