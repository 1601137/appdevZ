
Project link of Github:https: //github.com/1601137/appdevZ
----------------------------------------------------------
# This is version 1 of git example
-------------------------------------
      Acoustic Sensor using RPi3
-------------------------------------
Table of Content
1.Configuration Instructions
2.Installation Instructions


1.Configuration Instructions 

This section contains 2 parts:hardware configuration and software configuration.

1.1 Hardware configuration

This project is biult on a Raspberry Pi3,with a USB sound card and a microphone.
Ethernet connection is recommeded.If an older version of Raspberry Pi is used,
certain change might be necessary.

First you have to set USB sound card as defalt audio device

Second you need to downgrade the alsa-utils from 1.0.28-1.0.25.
